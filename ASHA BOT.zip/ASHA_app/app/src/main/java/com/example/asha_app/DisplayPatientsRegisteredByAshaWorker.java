package com.example.asha_app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import org.w3c.dom.Text;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;

public class DisplayPatientsRegisteredByAshaWorker extends AppCompatActivity {
    TextView worker,display_patients;
    String to_date,from_date;
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference patients_collection=db.collection("PublicDetails");
    String worker_name;
    StringBuilder data;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_patients_registered_by_asha_worker);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        worker=(TextView) findViewById(R.id.worker_name);
        display_patients=(TextView)findViewById(R.id.display_patients);
        Intent intent=getIntent();
        worker_name=intent.getStringExtra("worker_name");
        to_date=intent.getStringExtra("to_date");
        from_date=intent.getStringExtra("from_date");
        //Toast.makeText(this, "from:"+from_date+"to:"+to_date, Toast.LENGTH_SHORT).show();
        worker.setText(worker_name);
        data = new StringBuilder();
        data.append("Date,Name,Mobile No,Adhar No,Age,Registered By,Temperature,KidneyAilment,Heart Ailment,Breathing Problem," +
                "Sore Throat,Cough,SpO2,Pregnant Women,Covid case in family,Travel History,Latitude,Longitude" );

        patients_collection.get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        String data1 = "";
                        int i=0;
                        for (QueryDocumentSnapshot documentSnapshot : queryDocumentSnapshots) {
                            String temp_registeredBy=documentSnapshot.getString("registeredBy");
                            String temp_date = documentSnapshot.getString("date");
                            if(worker_name.equals("All"))
                            {
                                if(!from_date.equals("") && !to_date.equals(""))
                                {
                                    try {
                                        if(dateFormat.parse(temp_date).compareTo(dateFormat.parse(from_date))>=0 && dateFormat.parse(temp_date).compareTo(dateFormat.parse(to_date))<=0)
                                        {
                                                String temp_temperature = documentSnapshot.getString("temperature");
                                                String temp_travel = documentSnapshot.getString("travel_history");
                                                String temp_public_name = documentSnapshot.getString("public_name");
                                                String temp_public_mobile_no = documentSnapshot.getString("public_mobile_no");
                                                String temp_age = documentSnapshot.getString("age");
                                                String temp_adhar = documentSnapshot.getString("adhar");
                                                String temp_covid_positive_in_family = documentSnapshot.getString("covid_positive_in_family");
                                                String temp_kidney_ailment = documentSnapshot.getString("kidney_ailment");
                                                String temp_heart_ailment = documentSnapshot.getString("heart_ailment");
                                                String temp_pregnant_women = documentSnapshot.getString("pregnant_women");
                                                String temp_breathing_problem = documentSnapshot.getString("breathing_problem");
                                                String temp_sore_throat = documentSnapshot.getString("sore_throat");
                                                String temp_cough = documentSnapshot.getString("cough");
                                                String temp_respiratory_rate = documentSnapshot.getString("respiratory_rate");
                                                String temp_latitude = documentSnapshot.getString("latitude");
                                                String temp_longitude = documentSnapshot.getString("longitude");
                                                i++;
                                                data1 += i+".\n"+"Date : "+temp_date + "\nAdhar: " + temp_adhar + "\nTemperature: " + temp_temperature +"\nSpO2 :"+
                                                        temp_respiratory_rate+"\nAge :"+ temp_age+"\n\n"+"--------------------------------\n";
                                                data.append("\n"+temp_date+","+temp_public_name+","+temp_public_mobile_no+","+temp_adhar+","+temp_age+","+temp_registeredBy
                                                        +","+temp_temperature+","+temp_kidney_ailment+","+temp_heart_ailment+","+temp_breathing_problem+","+temp_sore_throat
                                                        +","+temp_cough+","+temp_respiratory_rate+","+temp_pregnant_women+","+temp_covid_positive_in_family+
                                                        ","+temp_travel+","+temp_latitude+","+temp_longitude);

                                        }
                                    } catch (Exception e) {
                                        //Toast.makeText(DisplayPatientsRegisteredByAshaWorker.this, "Error1", Toast.LENGTH_LONG).show();
                                    }

                                }
                                else if(from_date.equals("") && !to_date.equals(""))
                                {
                                    try {
                                        if(dateFormat.parse(temp_date).compareTo(dateFormat.parse(to_date))<=0)
                                        {
                                            String temp_temperature = documentSnapshot.getString("temperature");
                                            String temp_travel = documentSnapshot.getString("travel_history");
                                            String temp_public_name = documentSnapshot.getString("public_name");
                                            String temp_public_mobile_no = documentSnapshot.getString("public_mobile_no");
                                            String temp_age = documentSnapshot.getString("age");
                                            String temp_adhar = documentSnapshot.getString("adhar");
                                            String temp_covid_positive_in_family = documentSnapshot.getString("covid_positive_in_family");
                                            String temp_kidney_ailment = documentSnapshot.getString("kidney_ailment");
                                            String temp_heart_ailment = documentSnapshot.getString("heart_ailment");
                                            String temp_pregnant_women = documentSnapshot.getString("pregnant_women");
                                            String temp_breathing_problem = documentSnapshot.getString("breathing_problem");
                                            String temp_sore_throat = documentSnapshot.getString("sore_throat");
                                            String temp_cough = documentSnapshot.getString("cough");
                                            String temp_respiratory_rate = documentSnapshot.getString("respiratory_rate");
                                            String temp_latitude = documentSnapshot.getString("latitude");
                                            String temp_longitude = documentSnapshot.getString("longitude");
                                            i++;
                                            data1 += i+".\n"+"Date : "+temp_date + "\nAdhar: " + temp_adhar + "\nTemperature: " + temp_temperature +"\nSpO2 :"+
                                                    temp_respiratory_rate+"\nAge :"+ temp_age+"\n\n"+"--------------------------------\n";
                                            data.append("\n"+temp_date+","+temp_public_name+","+temp_public_mobile_no+","+temp_adhar+","+temp_age+","+temp_registeredBy
                                                    +","+temp_temperature+","+temp_kidney_ailment+","+temp_heart_ailment+","+temp_breathing_problem+","+temp_sore_throat
                                                    +","+temp_cough+","+temp_respiratory_rate+","+temp_pregnant_women+","+temp_covid_positive_in_family+
                                                    ","+temp_travel+","+temp_latitude+","+temp_longitude);

                                        }
                                    } catch (Exception e) {
                                        //Toast.makeText(DisplayPatientsRegisteredByAshaWorker.this, "Error2", Toast.LENGTH_LONG).show();
                                    }

                                }
                                else if(!from_date.equals("") && to_date.equals(""))
                                {
                                    try {
                                        if(dateFormat.parse(temp_date).compareTo(dateFormat.parse(from_date))>=0 )
                                        {
                                            String temp_temperature = documentSnapshot.getString("temperature");
                                            String temp_travel = documentSnapshot.getString("travel_history");
                                            String temp_public_name = documentSnapshot.getString("public_name");
                                            String temp_public_mobile_no = documentSnapshot.getString("public_mobile_no");
                                            String temp_age = documentSnapshot.getString("age");
                                            String temp_adhar = documentSnapshot.getString("adhar");
                                            String temp_covid_positive_in_family = documentSnapshot.getString("covid_positive_in_family");
                                            String temp_kidney_ailment = documentSnapshot.getString("kidney_ailment");
                                            String temp_heart_ailment = documentSnapshot.getString("heart_ailment");
                                            String temp_pregnant_women = documentSnapshot.getString("pregnant_women");
                                            String temp_breathing_problem = documentSnapshot.getString("breathing_problem");
                                            String temp_sore_throat = documentSnapshot.getString("sore_throat");
                                            String temp_cough = documentSnapshot.getString("cough");
                                            String temp_respiratory_rate = documentSnapshot.getString("respiratory_rate");
                                            String temp_latitude = documentSnapshot.getString("latitude");
                                            String temp_longitude = documentSnapshot.getString("longitude");
                                            i++;
                                            data1 += i+".\n"+"Date : "+temp_date + "\nAdhar: " + temp_adhar + "\nTemperature: " + temp_temperature +"\nSpO2 :"+
                                                    temp_respiratory_rate+"\nAge :"+ temp_age+"\n\n"+"--------------------------------\n";
                                            data.append("\n"+temp_date+","+temp_public_name+","+temp_public_mobile_no+","+temp_adhar+","+temp_age+","+temp_registeredBy
                                                    +","+temp_temperature+","+temp_kidney_ailment+","+temp_heart_ailment+","+temp_breathing_problem+","+temp_sore_throat
                                                    +","+temp_cough+","+temp_respiratory_rate+","+temp_pregnant_women+","+temp_covid_positive_in_family+
                                                    ","+temp_travel+","+temp_latitude+","+temp_longitude);

                                        }
                                    } catch (Exception e) {
                                        //Toast.makeText(DisplayPatientsRegisteredByAshaWorker.this, "Error3", Toast.LENGTH_LONG).show();
                                    }

                                }
                                else if(from_date.equals("") && to_date.equals(""))
                                {
                                    String temp_temperature = documentSnapshot.getString("temperature");
                                    String temp_travel = documentSnapshot.getString("travel_history");
                                    String temp_public_name = documentSnapshot.getString("public_name");
                                    String temp_public_mobile_no = documentSnapshot.getString("public_mobile_no");
                                    String temp_age = documentSnapshot.getString("age");
                                    String temp_adhar = documentSnapshot.getString("adhar");
                                    String temp_covid_positive_in_family = documentSnapshot.getString("covid_positive_in_family");
                                    String temp_kidney_ailment = documentSnapshot.getString("kidney_ailment");
                                    String temp_heart_ailment = documentSnapshot.getString("heart_ailment");
                                    String temp_pregnant_women = documentSnapshot.getString("pregnant_women");
                                    String temp_breathing_problem = documentSnapshot.getString("breathing_problem");
                                    String temp_sore_throat = documentSnapshot.getString("sore_throat");
                                    String temp_cough = documentSnapshot.getString("cough");
                                    String temp_respiratory_rate = documentSnapshot.getString("respiratory_rate");
                                    String temp_latitude = documentSnapshot.getString("latitude");
                                    String temp_longitude = documentSnapshot.getString("longitude");
                                    i++;
                                    data1 += i+".\n"+"Date : "+temp_date + "\nAdhar: " + temp_adhar + "\nTemperature: " + temp_temperature +"\nSpO2 :"+
                                            temp_respiratory_rate+"\nAge :"+ temp_age+"\n\n"+"--------------------------------\n";
                                    data.append("\n"+temp_date+","+temp_public_name+","+temp_public_mobile_no+","+temp_adhar+","+temp_age+","+temp_registeredBy
                                            +","+temp_temperature+","+temp_kidney_ailment+","+temp_heart_ailment+","+temp_breathing_problem+","+temp_sore_throat
                                            +","+temp_cough+","+temp_respiratory_rate+","+temp_pregnant_women+","+temp_covid_positive_in_family+
                                            ","+temp_travel+","+temp_latitude+","+temp_longitude);

                                }

                            }
                            else{
                                if(!from_date.equals("") && !to_date.equals(""))
                                {
                                    try {
                                        if(dateFormat.parse(temp_date).compareTo(dateFormat.parse(from_date))>=0 && dateFormat.parse(temp_date).compareTo(dateFormat.parse(to_date))<=0)
                                            if(temp_registeredBy.equals(worker_name)){
                                            String temp_temperature = documentSnapshot.getString("temperature");
                                            String temp_travel = documentSnapshot.getString("travel_history");
                                            String temp_public_name = documentSnapshot.getString("public_name");
                                            String temp_public_mobile_no = documentSnapshot.getString("public_mobile_no");
                                                String temp_age = documentSnapshot.getString("age");
                                            String temp_adhar = documentSnapshot.getString("adhar");
                                            String temp_covid_positive_in_family = documentSnapshot.getString("covid_positive_in_family");
                                            String temp_kidney_ailment = documentSnapshot.getString("kidney_ailment");
                                            String temp_heart_ailment = documentSnapshot.getString("heart_ailment");
                                            String temp_pregnant_women = documentSnapshot.getString("pregnant_women");
                                            String temp_breathing_problem = documentSnapshot.getString("breathing_problem");
                                            String temp_sore_throat = documentSnapshot.getString("sore_throat");
                                            String temp_cough = documentSnapshot.getString("cough");
                                            String temp_respiratory_rate = documentSnapshot.getString("respiratory_rate");
                                            String temp_latitude = documentSnapshot.getString("latitude");
                                            String temp_longitude = documentSnapshot.getString("longitude");
                                            i++;
                                            data1 += i+".\n"+"Date : "+temp_date + "\nAdhar: " + temp_adhar + "\nTemperature: " + temp_temperature +"\nSpO2 :"+
                                                    temp_respiratory_rate+"\nAge :"+ temp_age+"\n\n"+"--------------------------------\n";
                                            data.append("\n"+temp_date+","+temp_public_name+","+temp_public_mobile_no+","+temp_adhar+","+temp_age+","+temp_registeredBy
                                                    +","+temp_temperature+","+temp_kidney_ailment+","+temp_heart_ailment+","+temp_breathing_problem+","+temp_sore_throat
                                                    +","+temp_cough+","+temp_respiratory_rate+","+temp_pregnant_women+","+temp_covid_positive_in_family+
                                                    ","+temp_travel+","+temp_latitude+","+temp_longitude);

                                        }
                                    } catch (Exception e) {
                                        //Toast.makeText(DisplayPatientsRegisteredByAshaWorker.this, "Error4", Toast.LENGTH_LONG).show();
                                    }

                                }
                                else if(from_date.equals("") && !to_date.equals(""))
                                {
                                    try {
                                        if(dateFormat.parse(temp_date).compareTo(dateFormat.parse(to_date))<=0)
                                            if(temp_registeredBy.equals(worker_name)){
                                            String temp_temperature = documentSnapshot.getString("temperature");
                                            String temp_travel = documentSnapshot.getString("travel_history");
                                            String temp_public_name = documentSnapshot.getString("public_name");
                                            String temp_public_mobile_no = documentSnapshot.getString("public_mobile_no");
                                                String temp_age = documentSnapshot.getString("age");
                                            String temp_adhar = documentSnapshot.getString("adhar");
                                            String temp_covid_positive_in_family = documentSnapshot.getString("covid_positive_in_family");
                                            String temp_kidney_ailment = documentSnapshot.getString("kidney_ailment");
                                            String temp_heart_ailment = documentSnapshot.getString("heart_ailment");
                                            String temp_pregnant_women = documentSnapshot.getString("pregnant_women");
                                            String temp_breathing_problem = documentSnapshot.getString("breathing_problem");
                                            String temp_sore_throat = documentSnapshot.getString("sore_throat");
                                            String temp_cough = documentSnapshot.getString("cough");
                                            String temp_respiratory_rate = documentSnapshot.getString("respiratory_rate");
                                            String temp_latitude = documentSnapshot.getString("latitude");
                                            String temp_longitude = documentSnapshot.getString("longitude");
                                            i++;
                                            data1 += i+".\n"+"Date : "+temp_date + "\nAdhar: " + temp_adhar + "\nTemperature: " + temp_temperature +"\nSpO2 :"+
                                                    temp_respiratory_rate+"\nAge :"+ temp_age+"\n\n"+"--------------------------------\n";
                                            data.append("\n"+temp_date+","+temp_public_name+","+temp_public_mobile_no+","+temp_adhar+","+temp_age+","+temp_registeredBy
                                                    +","+temp_temperature+","+temp_kidney_ailment+","+temp_heart_ailment+","+temp_breathing_problem+","+temp_sore_throat
                                                    +","+temp_cough+","+temp_respiratory_rate+","+temp_pregnant_women+","+temp_covid_positive_in_family+
                                                    ","+temp_travel+","+temp_latitude+","+temp_longitude);

                                        }
                                    } catch (Exception e) {
                                        //Toast.makeText(DisplayPatientsRegisteredByAshaWorker.this, "Error5", Toast.LENGTH_LONG).show();
                                    }

                                }
                                else if(!from_date.equals("") && to_date.equals(""))
                                {
                                    try {
                                        if(dateFormat.parse(temp_date).compareTo(dateFormat.parse(from_date))>=0 )
                                            if(temp_registeredBy.equals(worker_name)){
                                            String temp_temperature = documentSnapshot.getString("temperature");
                                            String temp_travel = documentSnapshot.getString("travel_history");
                                            String temp_public_name = documentSnapshot.getString("public_name");
                                            String temp_public_mobile_no = documentSnapshot.getString("public_mobile_no");
                                                String temp_age = documentSnapshot.getString("age");
                                            String temp_adhar = documentSnapshot.getString("adhar");
                                            String temp_covid_positive_in_family = documentSnapshot.getString("covid_positive_in_family");
                                            String temp_kidney_ailment = documentSnapshot.getString("kidney_ailment");
                                            String temp_heart_ailment = documentSnapshot.getString("heart_ailment");
                                            String temp_pregnant_women = documentSnapshot.getString("pregnant_women");
                                            String temp_breathing_problem = documentSnapshot.getString("breathing_problem");
                                            String temp_sore_throat = documentSnapshot.getString("sore_throat");
                                            String temp_cough = documentSnapshot.getString("cough");
                                            String temp_respiratory_rate = documentSnapshot.getString("respiratory_rate");
                                            String temp_latitude = documentSnapshot.getString("latitude");
                                            String temp_longitude = documentSnapshot.getString("longitude");
                                            i++;
                                            data1 += i+".\n"+"Date : "+temp_date + "\nAdhar: " + temp_adhar + "\nTemperature: " + temp_temperature +"\nSpO2 :"+
                                                    temp_respiratory_rate+"\nAge :"+ temp_age+"\n\n"+"--------------------------------\n";
                                            data.append("\n"+temp_date+","+temp_public_name+","+temp_public_mobile_no+","+temp_adhar+","+temp_age+","+temp_registeredBy
                                                    +","+temp_temperature+","+temp_kidney_ailment+","+temp_heart_ailment+","+temp_breathing_problem+","+temp_sore_throat
                                                    +","+temp_cough+","+temp_respiratory_rate+","+temp_pregnant_women+","+temp_covid_positive_in_family+
                                                    ","+temp_travel+","+temp_latitude+","+temp_longitude);

                                        }
                                    } catch (Exception e) {
                                        //Toast.makeText(DisplayPatientsRegisteredByAshaWorker.this, "Error6", Toast.LENGTH_LONG).show();
                                    }

                                }
                                else if(from_date.equals("") && to_date.equals("")){
                                    if(temp_registeredBy.equals(worker_name)){
                                        String temp_temperature = documentSnapshot.getString("temperature");
                                        String temp_travel = documentSnapshot.getString("travel_history");
                                        String temp_public_name = documentSnapshot.getString("public_name");
                                        String temp_public_mobile_no = documentSnapshot.getString("public_mobile_no");
                                        String temp_age = documentSnapshot.getString("age");
                                        String temp_adhar = documentSnapshot.getString("adhar");
                                        String temp_covid_positive_in_family = documentSnapshot.getString("covid_positive_in_family");
                                        String temp_kidney_ailment = documentSnapshot.getString("kidney_ailment");
                                        String temp_heart_ailment = documentSnapshot.getString("heart_ailment");
                                        String temp_pregnant_women = documentSnapshot.getString("pregnant_women");
                                        String temp_breathing_problem = documentSnapshot.getString("breathing_problem");
                                        String temp_sore_throat = documentSnapshot.getString("sore_throat");
                                        String temp_cough = documentSnapshot.getString("cough");
                                        String temp_respiratory_rate = documentSnapshot.getString("respiratory_rate");
                                        String temp_latitude = documentSnapshot.getString("latitude");
                                        String temp_longitude = documentSnapshot.getString("longitude");
                                        i++;
                                        data1 += i+".\n"+"Date : "+temp_date + "\nAdhar: " + temp_adhar + "\nTemperature: " + temp_temperature +"\nSpO2 :"+
                                                temp_respiratory_rate+"\nAge :"+ temp_age+"\n\n"+"--------------------------------\n";
                                        data.append("\n"+temp_date+","+temp_public_name+","+temp_public_mobile_no+","+temp_adhar+","+temp_age+","+temp_registeredBy
                                                +","+temp_temperature+","+temp_kidney_ailment+","+temp_heart_ailment+","+temp_breathing_problem+","+temp_sore_throat
                                                +","+temp_cough+","+temp_respiratory_rate+","+temp_pregnant_women+","+temp_covid_positive_in_family+
                                                ","+temp_travel+","+temp_latitude+","+temp_longitude);
                                    }

                                }

                            }

                        }
                        if(data1.equals("")){
                            display_patients.setText("No Data Available");

                        }else{
                            display_patients.setText(data1);
                        }}
                });


    }

    public void export(View view) {


        try{
            //saving the file into device
            String fname="Patients"+System.currentTimeMillis()+"";
            FileOutputStream out = openFileOutput(fname+".csv", Context.MODE_PRIVATE);
            out.write((data.toString()).getBytes());
            out.close();

            //exporting
            Context context = getApplicationContext();
            File filelocation = new File(getFilesDir(), fname+".csv");
            Uri path = FileProvider.getUriForFile(context, "com.example.asha_app.fileprovider", filelocation);
            Intent fileIntent = new Intent(Intent.ACTION_SEND);
            fileIntent.setType("text/csv");
            fileIntent.putExtra(Intent.EXTRA_SUBJECT, "Data");
            fileIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            fileIntent.putExtra(Intent.EXTRA_STREAM, path);
            startActivity(Intent.createChooser(fileIntent, "Send mail"));
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
}
