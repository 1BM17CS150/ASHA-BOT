package com.example.asha_app;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.nex3z.togglebuttongroup.SingleSelectToggleGroup;
import com.rengwuxian.materialedittext.MaterialEditText;
import com.weiwangcn.betterspinner.library.material.MaterialBetterSpinner;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Collect_details_of_public extends AppCompatActivity  implements LocationListener{
    Button submit;
    private DatabaseReference Post;
    String latitude="ini";
    String longitude="ini";
    String str_temperature,str_respiratory_rate,str_travelHistory;
    String cough="No",breathing_problem="No",sore_throat="No",kidney_ailment="No",heart_ailment="No",covid_positive_in_family="No",pregnant_woman="No",currentTime="";
    TextView date,textView_Patient_name,respiratory_rate,temperature;
    Spinner travelHistory;
    private FirebaseFirestore db_public_data = FirebaseFirestore.getInstance();
 int saveflag=0;
    LocationManager locationManager;
    String mprovider;

    private FirebaseFirestore db_public_details = FirebaseFirestore.getInstance();
    private CollectionReference public_details_collection=db_public_details.collection("PublicDetails") ;
    private DocumentReference public_details_documents ;
    String worker_name,patient_name,adhar_no,mobile_no,temp_age;

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_collect_details_of_public);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        Post = FirebaseDatabase.getInstance().getReference();
        final Spinner dropdown = findViewById(R.id.spinner);
        String[] SPINNERLIST = {"None", "National","International"};
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_dropdown_item_1line, SPINNERLIST);
        travelHistory = (Spinner)
                findViewById(R.id.travel_history_spinner);
        travelHistory.setAdapter(arrayAdapter);
        Intent intent=getIntent();
        worker_name=intent.getStringExtra("worker_name");
        patient_name=intent.getStringExtra("patient_name");
        adhar_no=intent.getStringExtra("adhar_no");
        temp_age=intent.getStringExtra("age");
        mobile_no=intent.getStringExtra("mobile_no");
        textView_Patient_name=(TextView) findViewById(R.id.name);
        textView_Patient_name.setText(patient_name);
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        try {
            Date date1 = new Date();
            currentTime = dateFormat.format(date1);
        } catch (Exception e) {
            Toast.makeText(this, "Error", Toast.LENGTH_LONG).show();
        }
        if(currentTime.equals("")){
            Toast.makeText(this, "Some error in fetching time", Toast.LENGTH_LONG).show();
            return;
        }
        date=(TextView)findViewById(R.id.date);
        date.setText(currentTime);
        respiratory_rate=(TextView) findViewById(R.id.respiratory_rate);
        temperature=(TextView) findViewById(R.id.temperature);
        //checkLocationPermission();
        //getGPSLocation();
        Checklocationpermision(Collect_details_of_public.this);
        getGPSLocation();
        SingleSelectToggleGroup breathing_problem_options = (SingleSelectToggleGroup) findViewById(R.id.breathing_problem_choices);
        breathing_problem_options.setOnCheckedChangeListener(new SingleSelectToggleGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(SingleSelectToggleGroup group, int checkedId) {
                if(checkedId==R.id.breathing_problem_yes){
                    breathing_problem="Yes";
                    //Toast.makeText(Collect_details_of_public.this, "Breathing "+breathing_problem, Toast.LENGTH_SHORT).show();
                }
                if(checkedId==R.id.breathing_problem_no){
                    breathing_problem="No";
                    //Toast.makeText(Collect_details_of_public.this, "Breathing "+breathing_problem, Toast.LENGTH_SHORT).show();
                }

            }
        });

        SingleSelectToggleGroup cough_options = (SingleSelectToggleGroup) findViewById(R.id.cough_choices);
        cough_options.setOnCheckedChangeListener(new SingleSelectToggleGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(SingleSelectToggleGroup group, int checkedId) {
                if(checkedId==R.id.cough_yes){
                    cough="Yes";
                    //Toast.makeText(Collect_details_of_public.this, "Cough "+cough, Toast.LENGTH_SHORT).show();
                    }
                if(checkedId==R.id.cough_no){
                    cough="No";
                    //Toast.makeText(Collect_details_of_public.this, "Cough "+cough, Toast.LENGTH_SHORT).show();
                }

            }
        });

        SingleSelectToggleGroup sore_throat_options = (SingleSelectToggleGroup) findViewById(R.id.sore_throat_choices);
        sore_throat_options.setOnCheckedChangeListener(new SingleSelectToggleGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(SingleSelectToggleGroup group, int checkedId) {
                if(checkedId==R.id.sore_throat_yes){
                    sore_throat="Yes";
                }
                if(checkedId==R.id.sore_throat_no){
                    sore_throat="No";
                }

            }
        });
        SingleSelectToggleGroup kidney_ailment_options = (SingleSelectToggleGroup) findViewById(R.id.kidney_ailment_choices);
        kidney_ailment_options.setOnCheckedChangeListener(new SingleSelectToggleGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(SingleSelectToggleGroup group, int checkedId) {
                if(checkedId==R.id.kidney_ailment_yes){
                    kidney_ailment="Yes";
                }
                if(checkedId==R.id.kidney_ailment_no){
                    kidney_ailment="No";
                }

            }
        });
        SingleSelectToggleGroup heart_ailment_options = (SingleSelectToggleGroup) findViewById(R.id.heart_ailment_choices);
        heart_ailment_options.setOnCheckedChangeListener(new SingleSelectToggleGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(SingleSelectToggleGroup group, int checkedId) {
                if(checkedId==R.id.heart_ailment_yes){
                    heart_ailment="Yes";
                }
                if(checkedId==R.id.heart_ailment_no){
                    heart_ailment="No";
                }

            }
        });
        SingleSelectToggleGroup covid_positive_in_family_options = (SingleSelectToggleGroup) findViewById(R.id.family_positive_choices);
        covid_positive_in_family_options.setOnCheckedChangeListener(new SingleSelectToggleGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(SingleSelectToggleGroup group, int checkedId) {
                if(checkedId==R.id.family_positive_yes){
                    covid_positive_in_family="Yes";
                }
                if(checkedId==R.id.family_positive_no){
                    covid_positive_in_family="No";
                }

            }
        });
        SingleSelectToggleGroup pregnant_women_options = (SingleSelectToggleGroup) findViewById(R.id.pregnant_women_choices);
        pregnant_women_options.setOnCheckedChangeListener(new SingleSelectToggleGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(SingleSelectToggleGroup group, int checkedId) {
                if(checkedId==R.id.pregnant_women_yes){
                    pregnant_woman="Yes";
                }
                if(checkedId==R.id.pregnant_women_no){
                    pregnant_woman="No";
                }

            }
        });

    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent i=new Intent(getApplicationContext(),Asha_worker_page.class);
        i.putExtra("worker_name",worker_name);
        startActivity(i);
        finish();
    }


    @Override
    public void onLocationChanged(Location location) {
        latitude=location.getLatitude()+"";
        longitude=location.getLongitude()+"";
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
    }

    @Override
    public void onProviderEnabled(String provider) {
        Toast.makeText(getBaseContext(), "GPS is turned on!! ",
                Toast.LENGTH_SHORT).show();
    }
    @Override
    public void onProviderDisabled(String provider) {
        Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
        startActivity(intent);
        Toast.makeText(getBaseContext(), "GPS is turned off!! ",
                Toast.LENGTH_SHORT).show();
    }
    @RequiresApi(api = Build.VERSION_CODES.M)
    public void getGPSLocation() {
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        Criteria criteria = new Criteria();

        mprovider = locationManager.getBestProvider(criteria, true);

        if (mprovider != null && !mprovider.equals("")) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            Location location = locationManager.getLastKnownLocation(mprovider);
            locationManager.requestLocationUpdates(mprovider, 15000, 1, (LocationListener) this);

            if (location != null)
                onLocationChanged(location);
            else
                Toast.makeText(getBaseContext(), "No Location Provider Found ", Toast.LENGTH_SHORT).show();
        }

       /* LocationManager locationManager;
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    Activity#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for Activity#requestPermissions for more details.
            return;
        }
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000, 1, this);*/
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public void submit(View view) {
        Checklocationpermision(Collect_details_of_public.this);
            getGPSLocation();

        final String adh=adhar_no;
        str_temperature=temperature.getText().toString();
        str_respiratory_rate=respiratory_rate.getText().toString();
        str_travelHistory=travelHistory.getSelectedItem().toString();

        Map<String, Object> note = new HashMap<>();
        note.put("registeredBy", worker_name);
        note.put("temperature", str_temperature);
        note.put("travel_history",str_travelHistory);
        note.put("public_name",patient_name);
        note.put("public_mobile_no",mobile_no);
        note.put("date",currentTime);
        note.put("adhar",adh);
        note.put("age",temp_age);
        note.put("covid_positive_in_family",covid_positive_in_family);
        note.put("kidney_ailment",kidney_ailment);
        note.put("heart_ailment",heart_ailment);
        note.put("pregnant_women",pregnant_woman);
        note.put("breathing_problem",breathing_problem);
        note.put("sore_throat",sore_throat);
        note.put("cough",cough);
        note.put("respiratory_rate",str_respiratory_rate);
        int flag=0;
        if (str_temperature.isEmpty()||str_respiratory_rate.isEmpty()){
            Toast.makeText(getApplicationContext(), "Fields are empty", Toast.LENGTH_SHORT).show();
            flag=1;
        }
        if (latitude.isEmpty() || longitude.isEmpty())
        {
            getGPSLocation();
            Toast.makeText(getApplicationContext(), "Unable to fetch location !", Toast.LENGTH_SHORT).show();
            flag=1;
        }else{
            note.put("latitude",latitude);
            note.put("longitude",longitude);
        }
        if(flag==0){
            public_details_documents=public_details_collection.document(adh);
            public_details_documents.set(note).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void aVoid) {
                    Toast.makeText(getApplicationContext(), "Data Recorded", Toast.LENGTH_SHORT).show();
                }}).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(getApplicationContext(), "Error!", Toast.LENGTH_SHORT).show();
                    Log.d("Error", e.toString());
                }});
            addItemToSheet();

        }
    }
    private void   addItemToSheet() {

        final ProgressDialog loading = ProgressDialog.show(this,"Adding Details","Please wait");
        StringRequest stringRequest = new StringRequest(Request.Method.POST, "https://script.google.com/macros/s/AKfycbzhqDTghZ3YkoVwBBX92KnVr5SLpKysLG9fDiQW3zYbdJELm8oK/exec",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        loading.dismiss();
                        Intent intent = new Intent(getApplicationContext(), Asha_worker_page.class);
                        intent.putExtra("worker_name",worker_name);
                        startActivity(intent);

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        loading.dismiss();
                        Toast.makeText(getApplicationContext(),"some error occured", Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> parmas = new HashMap<>();
                //here we pass params
                parmas.put("action","addItem");
                parmas.put("registeredBy", worker_name);
                parmas.put("temperature", str_temperature);
                parmas.put("travel_history",str_travelHistory);
                parmas.put("public_name",patient_name);
                parmas.put("public_mobile_no",mobile_no);
                parmas.put("date",currentTime);
                parmas.put("adhar",adhar_no);
                //parmas.put("age",temp_age);
                parmas.put("covid_positive_in_family",covid_positive_in_family);
                parmas.put("kidney_ailment",kidney_ailment);
                parmas.put("heart_ailment",heart_ailment);
                parmas.put("pregnant_women",pregnant_woman);
                parmas.put("breathing_problem",breathing_problem);
                parmas.put("sore_throat",sore_throat);
                parmas.put("cough",cough);
                parmas.put("respiratory_rate",str_respiratory_rate);
                parmas.put("latitude",latitude);
                parmas.put("longitude",longitude);
                return parmas;
            }
        };

        int socketTimeOut = 10000;// u can change this .. here it is 50 seconds

        RetryPolicy retryPolicy = new DefaultRetryPolicy(socketTimeOut, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        stringRequest.setRetryPolicy(retryPolicy);
        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(stringRequest);
    }

    public void load_respiratory_data(View view) {
        Post.child("Data")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        String temp_result=dataSnapshot.child("RespiratoryRate").getValue(Float.class).toString();
                        respiratory_rate.setText(temp_result);
                        //Toast.makeText(Collect_details_of_public.this, "Respiratory Rate: "+temp_result, Toast.LENGTH_SHORT).show();

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(Collect_details_of_public.this, "Error!!!!!"+databaseError, Toast.LENGTH_SHORT).show();

                    }
                });
    }

    public void load_temperature(View view) {
        Post.child("Data")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        String temp_result=dataSnapshot.child("Temperature").getValue(Float.class).toString();
                        temperature.setText(temp_result);
                        //Toast.makeText(Collect_details_of_public.this, "Temperature :"+temp_result, Toast.LENGTH_SHORT).show();

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(Collect_details_of_public.this, "Error!!!!!"+databaseError, Toast.LENGTH_SHORT).show();

                    }
                });
    }

    public static boolean Checklocationpermision(Activity activity){
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (activity.checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION)
                        == PackageManager.PERMISSION_GRANTED) {
                    return true;

                } else {

                    activity.requestPermissions(new String[]{android.Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
                    return false;
                }
            }else {

                return true;
            }
    }


}
