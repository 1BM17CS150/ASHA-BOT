package com.example.asha_app;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class Remove_Worker extends AppCompatActivity {
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    //private DocumentReference noteRef = db.document("Workers/My First Note");
    EditText get_id;
    AlertDialog.Builder builder;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remove__worker);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        get_id=(EditText)findViewById(R.id.enter_id);
        builder = new AlertDialog.Builder(this);
    }

    public void remove_asha_worker(View view) {
        if(get_id.getText().toString().equals("")||get_id.getText().toString().equals(" ")){
            Toast.makeText(this, "ID not entered", Toast.LENGTH_SHORT).show();
        }
        else{
             final DocumentReference noteRef = db.document("Workers/"+get_id.getText().toString());
            builder.setMessage("Are you sure you want to delete worker with ID :"+get_id.getText().toString())
                    .setCancelable(false)
                    .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            noteRef.delete();
                            finish();
                        }
                    })
                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();

                        }
                    });
            AlertDialog alert = builder.create();
            alert.setTitle("Please Confirm");
            alert.show();
        }
    }
}