package com.example.asha_app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class Forgot_password extends AppCompatActivity {
    TextInputEditText user_name, mobile_number;
    String user_id="";
    Button submit;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference workers_collection = db.collection("Workers");
    AlertDialog.Builder builder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        user_name = (TextInputEditText) findViewById(R.id.username);
        mobile_number = (TextInputEditText) findViewById(R.id.mobile);
        builder = new AlertDialog.Builder(this);
        submit = (Button) findViewById(R.id.submit);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String u = user_name.getText().toString();
                final String m = mobile_number.getText().toString();

                if (u.isEmpty() || m.isEmpty()) {
                    Toast.makeText(Forgot_password.this, "Some field are  empty", Toast.LENGTH_LONG).show();
                } else {
                    workers_collection.get()
                            .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                                                      @Override
                                                      public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                                                          for (QueryDocumentSnapshot documentSnapshot : queryDocumentSnapshots) {

                                                                  String temp_name = documentSnapshot.getString("name");
                                                                  String temp_worker_id = documentSnapshot.getString("worker_id");
                                                                  String temp_mobile_no = documentSnapshot.getString("mobile_no");
                                                                  if(temp_name.equals(u)&&temp_mobile_no.equals(m)) {
                                                                      user_id = temp_worker_id;
                                                                      break;
                                                                  }
                                                          }
                                                          gotodisplay();
                                                      }
                                                  }
                            )
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(Forgot_password.this, "Try Again!", Toast.LENGTH_SHORT).show();
                        }
                    });
                }

            }


        });
    }
    public void gotodisplay(){
        if(user_id.equals("")){
            Toast.makeText(Forgot_password.this, "Check the Data and Try Again!", Toast.LENGTH_SHORT).show();
        }
        else{
        builder.setMessage("Your USER ID is : "+user_id)
                .setCancelable(false)
                .setPositiveButton("Go to Login", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        Intent intent=new Intent(Forgot_password.this,Main_login.class);
                        startActivity(intent);
                        finish();
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        user_id="";
                        user_name.setText("");
                        mobile_number.setText("");

                    }
                });
        AlertDialog alert = builder.create();
        alert.setTitle("Important");
        alert.show();
    }}
}
