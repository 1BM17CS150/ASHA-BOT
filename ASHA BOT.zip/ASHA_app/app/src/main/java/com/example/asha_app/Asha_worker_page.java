package com.example.asha_app;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

public class Asha_worker_page extends AppCompatActivity {
    Button register_public,collect_details;
    String worker_name;
    TextView worker_name_tv;
    AlertDialog.Builder builder;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_asha_worker_page);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        Intent admin_intent=getIntent();
        builder = new AlertDialog.Builder(this);
        worker_name=admin_intent.getStringExtra("worker_name");
        worker_name_tv=(TextView)findViewById(R.id.worker_name);
        worker_name_tv.setText(worker_name);
        
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        builder.setMessage("Going Back will Log Out Session!")
                .setCancelable(false)
                .setPositiveButton("Logout", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        finish();
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();

                    }
                });
        AlertDialog alert = builder.create();
        alert.setTitle("Please Confirm");
        alert.show();
    }

    public void Register(View view) {
        Intent i=new Intent(getApplicationContext(),Register_public_by_asha_worker.class);
        i.putExtra("worker_name",worker_name);
        startActivity(i);

    }

    public void Survey(View view) {
        Intent intent=new Intent(getApplicationContext(),ConfirmPatientsBeforeCollectingDetails.class);
        intent.putExtra("worker_name",worker_name);
        startActivity(intent);
    }

    public void Hospital(View view) {
        Intent intent=new Intent(getApplicationContext(),hospital_data_by_worker.class);
        intent.putExtra("worker_name",worker_name);
        startActivity(intent);
    }

    public void Containment(View view) {
        Intent intent=new Intent(getApplicationContext(),containment_data_by_workers.class);
        intent.putExtra("worker_name",worker_name);
        startActivity(intent);
    }

    public void Quarantine(View view) {
        Intent intent=new Intent(getApplicationContext(),quarantine_data_by_workers.class);
        intent.putExtra("worker_name",worker_name);
        startActivity(intent);
    }


    public void logout(View view) {
        Intent intent = new Intent(getApplicationContext(), Main_login.class);
        startActivity(intent);
        finish();
    }
}
