package com.example.asha_app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.io.File;
import java.io.FileOutputStream;

public class ViewRegisteredPublicData extends AppCompatActivity {
    TextView display_public_details;//worker
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference public_collection=db.collection("PublicData");
    //String worker_name;
    StringBuilder data;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_registered_public_data);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        display_public_details=(TextView)findViewById(R.id.display_public_detials);
        Intent intent=getIntent();
        //worker_name=intent.getStringExtra("worker_name");
        //worker.setText(worker_name);
        data = new StringBuilder();
        data.append("Name,Adhar No,Mobile No,Date Of Birth,House No,Area,City,State,Pin Code,Registered By" );

        public_collection.get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        String data1 = "";
                        int i=0;
                        for (QueryDocumentSnapshot documentSnapshot : queryDocumentSnapshots) {{
                            String temp_name=documentSnapshot.getString("name");
                            String temp_adhar_no = documentSnapshot.getString("adhar_no");
                            String temp_mobile_no = documentSnapshot.getString("mobile_no");
                            String temp_dob = documentSnapshot.getString("dob");
                            String temp_house_no = documentSnapshot.getString("house_no");
                            String temp_area_name = documentSnapshot.getString("area_name");
                            String temp_city_name = documentSnapshot.getString("city_name");
                            String temp_state = documentSnapshot.getString("state");
                            String temp_pin_code = documentSnapshot.getString("pin_code");
                            String temp_registeredBy = documentSnapshot.getString("registeredBy");


                            i++;
                            data1 += i+".\n"+"Name : "+temp_name + "\nAdhar No : " +temp_adhar_no +"\nArea : " +temp_area_name +
                                    "\nMobile No : " +temp_mobile_no +"\nDOB : " +temp_dob +"\nRegistered By : " +temp_registeredBy +
                                    "\n\n"+"--------------------------------\n";
                            data.append("\n"+temp_name+","+temp_adhar_no+","+temp_mobile_no+","+temp_dob+
                                    ","+temp_house_no+","+temp_area_name+","+temp_city_name+","+temp_state+","+temp_pin_code+","+temp_registeredBy);
                        }
                        }
                        if(data1.equals("")){
                            display_public_details.setText("No Data Available");

                        }else{
                            display_public_details.setText(data1);
                        }}
                });
    }

    public void export(View view) {
        try{
            //saving the file into device
            String fname="PublicData"+System.currentTimeMillis()+"";
            FileOutputStream out = openFileOutput(fname+".csv", Context.MODE_PRIVATE);
            out.write((data.toString()).getBytes());
            out.close();

            //exporting
            Context context = getApplicationContext();
            File filelocation = new File(getFilesDir(), fname+".csv");
            Uri path = FileProvider.getUriForFile(context, "com.example.asha_app.fileprovider", filelocation);
            Intent fileIntent = new Intent(Intent.ACTION_SEND);
            fileIntent.setType("text/csv");
            fileIntent.putExtra(Intent.EXTRA_SUBJECT, "Data");
            fileIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            fileIntent.putExtra(Intent.EXTRA_STREAM, path);
            startActivity(Intent.createChooser(fileIntent, "Send mail"));
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
}