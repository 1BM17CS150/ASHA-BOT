package com.example.asha_app;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.rengwuxian.materialedittext.MaterialEditText;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class quarantine_data_by_workers extends AppCompatActivity implements LocationListener {
    int img_flag=0,save_flag=0;
    TextView date;
    String dateTime="";
    String latitude="";
    String longitude="";

    MaterialEditText name,no_of_patients;
    Button img1,img2,img3;
    String temp_img1="",temp_img2="",temp_img3="";
    String str_name,str_patients;
    String worker_name;


    LocationManager locationManager;
    String mprovider;

    private FirebaseFirestore db_camp_details = FirebaseFirestore.getInstance();
    private CollectionReference camp_details_collection=db_camp_details.collection("QuarantineCampData") ;
    private DocumentReference camp_details_documents ;
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quarantine_data_by_workers);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        Intent intent=getIntent();
        worker_name=intent.getStringExtra("worker_name");
        date=(TextView)findViewById(R.id.date);
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        try {
            Date date1 = new Date();
            dateTime = dateFormat.format(date1);
        } catch (Exception e) {
            Toast.makeText(this, "Error", Toast.LENGTH_LONG).show();
        }
        if(dateTime.equals("")){
            Toast.makeText(this, "Some error in fetching time", Toast.LENGTH_LONG).show();
            return;
        }
        date.setText(dateTime);
        img1=(Button)findViewById(R.id.image1);
        img2=(Button)findViewById(R.id.image2);
        img3=(Button)findViewById(R.id.image3);
        name=(MaterialEditText)findViewById(R.id.name);
        no_of_patients=(MaterialEditText)findViewById(R.id.total_patients);
        //getGPSLocation();
        if(Checklocationpermision(quarantine_data_by_workers.this)){
            getGPSLocation();
        }
    }
    public void onBackPressed() {
        super.onBackPressed();
        /*Intent i=new Intent(getApplicationContext(),Asha_worker_page.class);
        i.putExtra("worker_name",worker_name);
        startActivity(i);
        finish();*/
    }

    public void Submit(View view) {
        if(save_flag==1){
            camp_details_documents.get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {
                                temp_img1 = documentSnapshot.getString("Image1");
                                temp_img2 = documentSnapshot.getString("Image2");
                                temp_img3 = documentSnapshot.getString("Image3");
                                addItemToSheet();
                            }
                            else {
                                Toast.makeText(getApplicationContext(), "Camp Does Not Exists", Toast.LENGTH_LONG).show();
                            }
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(getApplicationContext(), "Error!", Toast.LENGTH_SHORT).show();
                            Log.d("Error", e.toString());
                        }
                    });}
        else{
            Toast.makeText(this, "Save File before submitting", Toast.LENGTH_SHORT).show();
        }



    }

    @Override
    public void onLocationChanged(Location location) {
        latitude=location.getLatitude()+"";
        longitude=location.getLongitude()+"";

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {
        Toast.makeText(getBaseContext(), "GPS is turned on!! ",
                Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onProviderDisabled(String provider) {
        Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
        startActivity(intent);
        Toast.makeText(getBaseContext(), "GPS is turned off!! ",
                Toast.LENGTH_SHORT).show();
    }
    @RequiresApi(api = Build.VERSION_CODES.M)
    public void getGPSLocation() {
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        Criteria criteria = new Criteria();

        mprovider = locationManager.getBestProvider(criteria, true);

        if (mprovider != null && !mprovider.equals("")) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            Location location = locationManager.getLastKnownLocation(mprovider);
            locationManager.requestLocationUpdates(mprovider, 15000, 1, (LocationListener) this);

            if (location != null)
                onLocationChanged(location);
            else
                Toast.makeText(getBaseContext(), "No Location Provider Found ", Toast.LENGTH_SHORT).show();
        }

        /*LocationManager locationManager;
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    Activity#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for Activity#requestPermissions for more details.
            return;
        }
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000, 1, this);*/
    }
    private void   addItemToSheet() {

        final ProgressDialog loading = ProgressDialog.show(this,"Adding Details","Please wait");
        StringRequest stringRequest = new StringRequest(Request.Method.POST, "https://script.google.com/macros/s/AKfycbzhqDTghZ3YkoVwBBX92KnVr5SLpKysLG9fDiQW3zYbdJELm8oK/exec",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        loading.dismiss();
                        Intent intent = new Intent(getApplicationContext(), Asha_worker_page.class);
                        intent.putExtra("worker_name",worker_name);
                        startActivity(intent);
                        //finish();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        loading.dismiss();
                        Toast.makeText(getApplicationContext(), "some error occured", Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> parmas = new HashMap<>();
                //here we pass params
                parmas.put("action","quarantineCampData");
                parmas.put("collectedBy", worker_name);
                parmas.put("name_of_camp",str_name);
                parmas.put("no_of_patients",str_patients);
                parmas.put("latitude",latitude);
                parmas.put("longitude",longitude);
                parmas.put("image1",temp_img1);
                parmas.put("image2",temp_img2);
                parmas.put("image3",temp_img3);
                return parmas;
            }
        };

        int socketTimeOut = 10000;// u can change this .. here it is 50 seconds

        RetryPolicy retryPolicy = new DefaultRetryPolicy(socketTimeOut, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        stringRequest.setRetryPolicy(retryPolicy);
        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(stringRequest);
    }

    public void image2_upload(View view) {
        if(img_flag==1){
            Intent i=new Intent(getApplicationContext(),upload_image_for_quarantine_camp.class);
            i.putExtra("quarantine_camp_name",str_name);
            i.putExtra("image_no","Image2");
            img2.setTextColor(Color.GREEN);
            img2.setEnabled(false);

            startActivity(i);
        }else{
            Toast.makeText(this, "Save the Details before uploading images", Toast.LENGTH_SHORT).show();
        }
    }

    public void image3_upload(View view) {
        if(img_flag==1){
            Intent i=new Intent(getApplicationContext(),upload_image_for_quarantine_camp.class);
            i.putExtra("quarantine_camp_name",str_name);
            i.putExtra("image_no","Image3");
            img3.setTextColor(Color.GREEN);
            img3.setEnabled(false);
            startActivity(i);
        }else{
            Toast.makeText(this, "Submit the Details before uploading images", Toast.LENGTH_SHORT).show();
        }
    }

    public void image1_upload(View view) {
        if(img_flag==1){
            Intent i=new Intent(getApplicationContext(),upload_image_for_quarantine_camp.class);
            i.putExtra("quarantine_camp_name",str_name);
            i.putExtra("image_no","Image1");
            img1.setTextColor(Color.GREEN);
            img1.setEnabled(false);
            startActivity(i);
        }else{
            Toast.makeText(this, "Submit the Details before uploading images", Toast.LENGTH_SHORT).show();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public void SaveFile(View view) {
        Checklocationpermision(quarantine_data_by_workers.this);
            getGPSLocation();

        str_name=name.getText().toString();
        str_patients=no_of_patients.getText().toString();
        Map<String, Object> note = new HashMap<>();

        note.put("collectedBy", worker_name);
        note.put("date",dateTime);
        note.put("name_of_camp",str_name);
        note.put("no_of_patients",str_patients);
        note.put("Image1",temp_img1);
        note.put("Image2",temp_img2);
        note.put("Image3",temp_img3);
        int flag=0;
        if (str_name.isEmpty()||str_patients.isEmpty()){
            Toast.makeText(getApplicationContext(), "Fields are empty", Toast.LENGTH_SHORT).show();
            flag=1;
        }
        if (latitude.isEmpty() || longitude.isEmpty())
        {
            getGPSLocation();
            Toast.makeText(getApplicationContext(), "Unable to fetch location !", Toast.LENGTH_SHORT).show();
            flag=1;
        }else{
            note.put("latitude",latitude);
            note.put("longitude",longitude);
        }
        if(flag==0){
            camp_details_documents=camp_details_collection.document(str_name);
           camp_details_documents.set(note).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void aVoid) {
                    Toast.makeText(getApplicationContext(), "Data Recorded", Toast.LENGTH_SHORT).show();
                    img_flag=1;
                    save_flag=1;
                    name.setEnabled(false);
                    no_of_patients.setEnabled(false);
                }}).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(getApplicationContext(), "Error!", Toast.LENGTH_SHORT).show();
                    Log.d("Error", e.toString());
                }});
        }
    }
    public static boolean Checklocationpermision(Activity activity){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (activity.checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) {
                return true;

            } else {

                activity.requestPermissions(new String[]{android.Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
                return false;
            }
        }else {

            return true;
        }
    }
}