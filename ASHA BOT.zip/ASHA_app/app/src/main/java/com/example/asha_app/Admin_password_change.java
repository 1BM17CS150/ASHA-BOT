package com.example.asha_app;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;

import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

public class Admin_password_change extends AppCompatActivity {
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    //private DocumentReference noteRef = db.document("Notebook/My First Note");
    String admin_name="";
    EditText new_pass;
    AlertDialog.Builder builder;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_password_change);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        new_pass=(EditText)findViewById(R.id.enter_new_passwrd);
        Intent intent=getIntent();
        admin_name=intent.getStringExtra("admin_name");
        builder = new AlertDialog.Builder(this);
    }

    public void UpdatePassword(View view) {
         final DocumentReference noteRef = db.document("Admin/"+admin_name);

        builder.setMessage("Your new password will be :"+new_pass.getText().toString())
                .setCancelable(false)
                .setPositiveButton("Update", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        noteRef.update("password",new_pass.getText().toString());
                        finish();
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();

                    }
                });
        AlertDialog alert = builder.create();
        alert.setTitle("Please Confirm");
        alert.show();
    }
    }
