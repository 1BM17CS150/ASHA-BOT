package com.example.asha_app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class Asha_worker_login extends AppCompatActivity {
    private FirebaseFirestore db=FirebaseFirestore.getInstance();
    private CollectionReference workers_collection=db.collection("Workers");
    private DocumentReference workers_document;
    TextInputEditText worker_name,worker_id;
    Button signin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_asha_worker_login);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        worker_id=(TextInputEditText)findViewById(R.id.worker_id);
        worker_name=(TextInputEditText)findViewById(R.id.worker_name);
        signin=(Button)findViewById(R.id.sign_in);
        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String uname=worker_name.getText().toString();
                final String uid=worker_id.getText().toString();
                int flag=0;
                if (uid.isEmpty()){
                    Toast.makeText(getApplicationContext(), "Fields are empty", Toast.LENGTH_SHORT).show();
                    flag=1;
                }
                if(flag==0){
                    workers_document=workers_collection.document(uid);
                    workers_document.get()
                            .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                                @Override
                                public void onSuccess(DocumentSnapshot documentSnapshot) {
                                    if (documentSnapshot.exists()) {
                                        String temp_name = documentSnapshot.getString("name");
                                        if(temp_name.equals(uname)){
                                            worker_id.setText("");
                                            worker_name.setText("");
                                            //Toast.makeText(getApplicationContext(), "User Exists", Toast.LENGTH_SHORT).show();
                                            Intent intent = new Intent(getApplicationContext(), Asha_worker_page.class);
                                            intent.putExtra("worker_name",uname);
                                            startActivity(intent);
                                            finish();
                                        }
                                        else
                                        {
                                            Toast.makeText(getApplicationContext(), "Wrong Data", Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                    else {
                                        Toast.makeText(getApplicationContext(), "User Does Not Exists", Toast.LENGTH_LONG).show();
                                    }
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(getApplicationContext(), "Error!", Toast.LENGTH_SHORT).show();
                                    Log.d("Error", e.toString());
                                }
                            });}
            }
        });
    }

    public void GotoResetPassword(View view) {
        Intent i =new Intent(getApplicationContext(),Forgot_password.class);
        startActivity(i);
        finish();
    }
}
