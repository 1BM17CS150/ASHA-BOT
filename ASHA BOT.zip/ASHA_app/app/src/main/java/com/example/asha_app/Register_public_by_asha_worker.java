package com.example.asha_app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Register_public_by_asha_worker extends AppCompatActivity {
    EditText name,mobile_no,adhar_no,house_no,area_name,city_name,state,pin_code;
    String age_of_person="";
    EditText date_of_birth;
    String str_name,str_mobile_no,str_adhar,str_house_no,str_dob,str_area_name,str_city_name,str_state,str_pin_code;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference user_collection = db.collection("PublicData");
    private DocumentReference user_document;
    String worker_name;
    Button register;
    public DatePickerDialog.OnDateSetListener mDateSetListener;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_public_by_asha_worker);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        name=(EditText)findViewById(R.id.name);
        mobile_no=(EditText)findViewById(R.id.mobile_no);
        Intent intent=getIntent();
        worker_name=intent.getStringExtra("worker_name");
        house_no=(EditText)findViewById(R.id.house_no);
        date_of_birth=(EditText) findViewById(R.id.dob);
        area_name=(EditText)findViewById(R.id.area_name);
        city_name=(EditText)findViewById(R.id.city_name);
        state=(EditText)findViewById(R.id.state_name);
        pin_code=(EditText)findViewById(R.id.pin_code);
        adhar_no=(EditText)findViewById(R.id.adhar_no);
        register=(Button)findViewById(R.id.register);
        date_of_birth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(
                        Register_public_by_asha_worker.this,
                        android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        mDateSetListener,
                        year,month,day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();


            }
        });
        mDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                month = month + 1;
                String date = String.format("%02d-%02d-%04d",day,month,year);
                try {
                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
                    Date date1 = new Date();
                    String dateTime1 = dateFormat.format(date1);
                    if((dateFormat.parse(date)).compareTo(dateFormat.parse(dateTime1))>0){
                        Toast.makeText(Register_public_by_asha_worker.this, "Improper date", Toast.LENGTH_SHORT).show();
                        date_of_birth.setText("");
                    }
                    else{
                        date_of_birth.setText(date);

                    }

                } catch (Exception e) {
                    Toast.makeText(Register_public_by_asha_worker.this, "Error", Toast.LENGTH_LONG).show();
                }

            }
        };
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                str_name = name.getText().toString();
                str_mobile_no = mobile_no.getText().toString();
                str_adhar = adhar_no.getText().toString();
                str_house_no=house_no.getText().toString();
                str_dob=date_of_birth.getText().toString();
                str_area_name=area_name.getText().toString();
                str_city_name=city_name.getText().toString();
                str_state=state.getText().toString();
                str_pin_code=pin_code.getText().toString();
                int flag=0;
                if(str_name.isEmpty()){
                    Toast.makeText(getApplicationContext(),"name empty",Toast.LENGTH_LONG).show();
                    flag=1;
                }
                else if(str_mobile_no.isEmpty()){
                    Toast.makeText(getApplicationContext(),"mobile number empty",Toast.LENGTH_LONG).show();
                    flag=1;
                }
                else if(str_adhar.isEmpty())
                {Toast.makeText(getApplicationContext(),"Adhar No. empty",Toast.LENGTH_LONG).show();
                    flag=1;
                }
                else if(str_pin_code.isEmpty())
                {Toast.makeText(getApplicationContext(),"Pin code empty",Toast.LENGTH_LONG).show();
                    flag=1;
                }
                else if(!str_pin_code.matches("[1-9][0-9]{5}"))
                {
                    Toast.makeText(getApplicationContext(),"Invalid Pin code",Toast.LENGTH_LONG).show();
                    flag=1;
                }
                else if (!str_mobile_no.matches("[987][0-9]{9}")) {
                    Toast.makeText(getApplicationContext(),"invalid mob no",Toast.LENGTH_LONG).show();
                    flag=1;
                }
                else if(!str_adhar.matches("[1-9][0-9]{11}")){
                    Toast.makeText(getApplicationContext(),"invalid adhar no",Toast.LENGTH_LONG).show();
                    flag=1;
                }
                if (flag==0){

                    Map<String, Object> note = new HashMap<>();
                    note.put("name", str_name);
                    note.put("mobile_no", str_mobile_no);
                    note.put("registeredBy",worker_name);
                    note.put("adhar_no",str_adhar);
                    note.put("state",str_state);
                    note.put("dob",str_dob);
                    note.put("age",getAge(str_dob));
                    note.put("house_no",str_house_no);
                    note.put("area_name",str_area_name);
                    note.put("city_name",str_city_name);
                    note.put("pin_code",str_pin_code);
                    user_document = user_collection.document(str_adhar);
                    user_document.set(note).
                            addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess (Void aVoid){
                                    Toast.makeText(getApplicationContext(), "Public Registered", Toast.LENGTH_LONG).show();
                                    name.setText("");
                                    mobile_no.setText("");
                                    adhar_no.setText("");
                                    house_no.setText("");
                                    //street_name.setText("");
                                    area_name.setText("");
                                    city_name.setText("");
                                    state.setText("");
                                    pin_code.setText("");
                                    Intent intent = new Intent(getApplicationContext(), Asha_worker_page.class);
                                    intent.putExtra("worker_name",worker_name);
                                    startActivity(intent);
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure (@NonNull Exception e){
                                            Toast.makeText(getApplicationContext(), "Error!", Toast.LENGTH_SHORT).show();
                                            Log.d("Error", e.toString());
                                        }
                                    });
                }
            }
        });
    }
    public String getAge(String dateofbirth){
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        int age = 0;
        try {
            Date date1 = dateFormat.parse(dateofbirth);
            Calendar now = Calendar.getInstance();
            Calendar dob = Calendar.getInstance();
            dob.setTime(date1);
            if (dob.after(now)) {
                throw new IllegalArgumentException("Can't be born in the future");
            }
            int year1 = now.get(Calendar.YEAR);
            int year2 = dob.get(Calendar.YEAR);
            age = year1 - year2;
            int month1 = now.get(Calendar.MONTH);
            int month2 = dob.get(Calendar.MONTH);
            if (month2 > month1) {
                age--;
            } else if (month1 == month2) {
                int day1 = now.get(Calendar.DAY_OF_MONTH);
                int day2 = dob.get(Calendar.DAY_OF_MONTH);
                if (day2 > day1) {
                    age--;
                }
            }
        } catch (ParseException e) {
            e.printStackTrace();
            age=0;
        }
        if(age==0){
            return "null";
        }
        return Integer.toString(age);


    }



}
