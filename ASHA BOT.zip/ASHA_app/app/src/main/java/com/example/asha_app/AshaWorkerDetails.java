package com.example.asha_app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.io.File;
import java.io.FileOutputStream;

public class AshaWorkerDetails extends AppCompatActivity {
    TextView display_worker_details;//worker
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference workers_collection=db.collection("Workers");
    //String worker_name;
    StringBuilder data;
    AlertDialog.Builder builder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_asha_worker_details);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        display_worker_details=(TextView)findViewById(R.id.display_asha_worker_data);
        Intent intent=getIntent();
        builder = new AlertDialog.Builder(this);
        //worker_name=intent.getStringExtra("worker_name");
        //worker.setText(worker_name);
        data = new StringBuilder();
       // data.append("Name,Adhar No,Mobile No,Date Of Birth,House No,Area,City,State,Pin Code,Registered By" );
        data.append("Name,ID,Mobile No" );
        workers_collection.get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        String data1 = "";
                        int i=0;
                        for (QueryDocumentSnapshot documentSnapshot : queryDocumentSnapshots) {{
                            String temp_name=documentSnapshot.getString("name");
                            String temp_worker_id = documentSnapshot.getString("worker_id");
                            String temp_mobile_no = documentSnapshot.getString("mobile_no");

                            i++;
                            data1 += i+".\n"+"Name : "+temp_name + "\nID : " +temp_worker_id +"\nMobile No : " +temp_mobile_no +
                                    "\n\n"+"--------------------------------\n";
                            data.append("\n"+temp_name+","+temp_worker_id+","+temp_mobile_no);
                        }
                        }
                        if(data1.equals("")){
                            display_worker_details.setText("No Data Available");

                        }else{
                            display_worker_details.setText(data1);
                        }}
                });
    }

    public void export(View view) {
        try{
            //saving the file into device
            String fname="WorkerData"+System.currentTimeMillis()+"";
            FileOutputStream out = openFileOutput(fname+".csv", Context.MODE_PRIVATE);
            out.write((data.toString()).getBytes());
            out.close();

            //exporting
            Context context = getApplicationContext();
            File filelocation = new File(getFilesDir(), fname+".csv");
            Uri path = FileProvider.getUriForFile(context, "com.example.asha_app.fileprovider", filelocation);
            Intent fileIntent = new Intent(Intent.ACTION_SEND);
            fileIntent.setType("text/csv");
            fileIntent.putExtra(Intent.EXTRA_SUBJECT, "Data");
            fileIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            fileIntent.putExtra(Intent.EXTRA_STREAM, path);
            startActivity(Intent.createChooser(fileIntent, "Send mail"));
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
}