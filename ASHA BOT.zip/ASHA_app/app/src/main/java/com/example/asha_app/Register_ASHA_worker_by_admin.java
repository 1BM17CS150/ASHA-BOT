package com.example.asha_app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class Register_ASHA_worker_by_admin extends AppCompatActivity {
    EditText name,mobile_no,user_id,email;
    String str_name,str_mobile_no,str_id;
    AlertDialog.Builder builder;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference user_collection = db.collection("Workers");
    private DocumentReference user_document;
    private CollectionReference workers_collection=db.collection("Workers");
    private DocumentReference workers_document;
    Button register,sendemail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register__a_s_h_a_worker_by_admin);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        name=(EditText)findViewById(R.id.name);
        mobile_no=(EditText)findViewById(R.id.mobile_no);
        user_id=(EditText)findViewById(R.id.user_id);
        register=(Button)findViewById(R.id.register);
        email=(EditText)findViewById(R.id.email_address);
        email.setVisibility(View.GONE);
        sendemail=(Button)findViewById(R.id.send_mail);
        sendemail.setVisibility(View.GONE);
        builder = new AlertDialog.Builder(this);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                str_name = name.getText().toString();
                str_mobile_no = mobile_no.getText().toString();
                str_id = user_id.getText().toString();
                int flag=0;
                if(str_name.isEmpty()){
                    Toast.makeText(getApplicationContext(),"name empty",Toast.LENGTH_LONG).show();
                    flag=1;
                }
                else if(str_mobile_no.isEmpty()){
                    Toast.makeText(getApplicationContext(),"mobile number empty",Toast.LENGTH_LONG).show();
                    flag=1;
                }
                else if(str_id.isEmpty())
                {Toast.makeText(getApplicationContext(),"id empty",Toast.LENGTH_LONG).show();
                    flag=1;
                }
                else if (!str_mobile_no.matches("[987][0-9]{9}")) {
                    Toast.makeText(getApplicationContext(),"Invalid mobile no",Toast.LENGTH_LONG).show();
                    flag=1;
                }
                if (flag==0){
                    workers_document=workers_collection.document(str_id);
                    workers_document.get()
                            .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                                @Override
                                public void onSuccess(DocumentSnapshot documentSnapshot) {
                                    if (documentSnapshot.exists()) {
                                        confirm_register_worker();
                                    }
                                    else {
                                        registerWorker();
                                    }
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(getApplicationContext(), "Error!", Toast.LENGTH_SHORT).show();
                                    Log.d("Error", e.toString());
                                }
                            });
                    //registerWorker();
                    /*Map<String, Object> note = new HashMap<>();
                    note.put("name", str_name);
                    note.put("mobile_no", str_mobile_no);
                    note.put("worker_id", str_id);
                    user_document = user_collection.document(str_id);
                    user_document.set(note).
                            addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess (Void aVoid){
                                    Toast.makeText(getApplicationContext(), "Worker Registered", Toast.LENGTH_LONG).show();
                                    name.setText("");
                                    mobile_no.setText("");
                                    user_id.setText("");
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure (@NonNull Exception e){
                                            Toast.makeText(getApplicationContext(), "Error!", Toast.LENGTH_SHORT).show();
                                            Log.d("Error", e.toString());
                                        }
                                    });*/
                }
            }
        });

    }
    public void registerWorker(){
        Map<String, Object> note = new HashMap<>();
        note.put("name", str_name);
        note.put("mobile_no", str_mobile_no);
        note.put("worker_id", str_id);
        user_document = user_collection.document(str_id);
        user_document.set(note).
                addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess (Void aVoid){
                        Toast.makeText(getApplicationContext(), "Worker Registered", Toast.LENGTH_LONG).show();
                        email.setVisibility(View.VISIBLE);
                        sendemail.setVisibility(View.VISIBLE);

                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure (@NonNull Exception e){
                        Toast.makeText(getApplicationContext(), "Error!", Toast.LENGTH_SHORT).show();
                        Log.d("Error", e.toString());
                    }
                });

    }
    public void confirm_register_worker(){
        builder.setMessage("User with this ID already exists. Continuing will update the existing user details and not create a new User.")
                .setCancelable(false)
                .setPositiveButton("Continue", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        registerWorker();
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();

                    }
                });
        AlertDialog alert = builder.create();
        alert.setTitle("Important! Please Confirm");
        alert.show();
    }

    public void sendmail(View view) {
        Intent emailintent = new Intent(Intent.ACTION_SEND);
        emailintent.putExtra(Intent.EXTRA_EMAIL, new String[]{email.getText().toString()});
        emailintent.putExtra(Intent.EXTRA_SUBJECT, "YOUR REGISTRATION DETAILS ARE!");
        emailintent.putExtra(Intent.EXTRA_TEXT, "Username : " + str_name + "\n ID : " + str_id);
        emailintent.setType("message/rfc822");
        startActivity(Intent.createChooser(emailintent, "Choose an Email client :"));
    }
}
