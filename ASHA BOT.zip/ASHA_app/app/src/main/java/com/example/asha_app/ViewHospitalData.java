package com.example.asha_app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.io.File;
import java.io.FileOutputStream;

public class ViewHospitalData extends AppCompatActivity {
    TextView display_hospitals;//worker
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference hospital_collection=db.collection("HospitalData");
    //String worker_name;
    StringBuilder data;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_hospital_data);
        display_hospitals=(TextView)findViewById(R.id.display_hospitals);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        Intent intent=getIntent();
        //worker_name=intent.getStringExtra("worker_name");
        //worker.setText(worker_name);
        data = new StringBuilder();
        data.append("Date,Name Of Hospital,Collected By,Total Beds,Vacant Beds,Samples Collected,Samples Checked," +
                "Samples Confirmed Positive,Latitude,Longitude,Image 1,Image 2,Image 3" );
        hospital_collection.get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        String data1 = "";
                        int i=0;
                        for (QueryDocumentSnapshot documentSnapshot : queryDocumentSnapshots) {{
                                String temp_collectedBy=documentSnapshot.getString("collectedBy");
                                String temp_name_of_hospital = documentSnapshot.getString("name_of_hospital");
                                String temp_samples_collected = documentSnapshot.getString("samples_collected");
                                String temp_samples_checked = documentSnapshot.getString("samples_checked");
                                String temp_samples_confirmed = documentSnapshot.getString("samples_confirmed");
                                String temp_date = documentSnapshot.getString("date");
                                String temp_total_beds = documentSnapshot.getString("total_beds");
                                String temp_vacant_beds = documentSnapshot.getString("vacant_beds");
                                String temp_image1 = documentSnapshot.getString("Image1");
                                String temp_image2 = documentSnapshot.getString("Image2");
                                String temp_image3 = documentSnapshot.getString("Image3");
                                String temp_latitude = documentSnapshot.getString("latitude");
                                String temp_longitude = documentSnapshot.getString("longitude");
                                i++;
                                data1 += i+".\n"+"Date : "+temp_date + "\nName : " + temp_name_of_hospital +"\nTotal Beds : " + temp_total_beds+ "\nVacant Beds : " +  temp_vacant_beds +"\nConfirmed Cases :"+
                                        temp_samples_confirmed+"\n\n"+"--------------------------------\n";
                                data.append("\n"+temp_date+","+temp_name_of_hospital+","+temp_collectedBy+","+temp_total_beds+","+temp_vacant_beds
                                        +","+temp_samples_collected+","+temp_samples_checked+","+temp_samples_confirmed+","+temp_latitude+","+temp_longitude
                                        +","+temp_image1+","+temp_image2+","+temp_image3);
                            }
                        }
                        if(data1.equals("")){
                            display_hospitals.setText("No Data Available");

                        }else{
                            display_hospitals.setText(data1);
                        }}
                });


    }

    public void export(View view) {
        try{
            //saving the file into device
            String fname="HospitalData"+System.currentTimeMillis()+"";
            FileOutputStream out = openFileOutput(fname+".csv", Context.MODE_PRIVATE);
            out.write((data.toString()).getBytes());
            out.close();

            //exporting
            Context context = getApplicationContext();
            File filelocation = new File(getFilesDir(), fname+".csv");
            Uri path = FileProvider.getUriForFile(context, "com.example.asha_app.fileprovider", filelocation);
            Intent fileIntent = new Intent(Intent.ACTION_SEND);
            fileIntent.setType("text/csv");
            fileIntent.putExtra(Intent.EXTRA_SUBJECT, "Data");
            fileIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            fileIntent.putExtra(Intent.EXTRA_STREAM, path);
            startActivity(Intent.createChooser(fileIntent, "Send mail"));
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
}