package com.example.asha_app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.io.File;
import java.io.FileOutputStream;

public class ViewQuarantineData extends AppCompatActivity {
    TextView display_quarantine_camp_data;//worker
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference quarantine_collection=db.collection("QuarantineCampData");
    //String worker_name;
    StringBuilder data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_quarantine_data);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        display_quarantine_camp_data=(TextView)findViewById(R.id.display_quarantine_data);
        Intent intent=getIntent();
        //worker_name=intent.getStringExtra("worker_name");
        //worker.setText(worker_name);
        data = new StringBuilder();
        data.append("Date,Name Of Quarantine Camp,No of Patients Quarantined,Collected By,Latitude,Longitude,Image 1,Image 2,Image 3" );
        quarantine_collection.get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        String data1 = "";
                        int i=0;
                        for (QueryDocumentSnapshot documentSnapshot : queryDocumentSnapshots) {{
                            String temp_collectedBy=documentSnapshot.getString("collectedBy");
                            String temp_name_of_camp = documentSnapshot.getString("name_of_camp");
                            String temp_no_of_patients= documentSnapshot.getString("no_of_patients");
                            String temp_date = documentSnapshot.getString("date");
                            String temp_image1 = documentSnapshot.getString("Image1");
                            String temp_image2 = documentSnapshot.getString("Image2");
                            String temp_image3 = documentSnapshot.getString("Image3");
                            String temp_latitude = documentSnapshot.getString("latitude");
                            String temp_longitude = documentSnapshot.getString("longitude");
                            i++;
                            data1 += i+".\n"+"Date : "+temp_date + "\nName of Camp : " +temp_name_of_camp +"\nQuarantined Patients : " + temp_no_of_patients +
                                   "\n\n"+"--------------------------------\n";
                            data.append("\n"+temp_date+","+temp_name_of_camp+","+temp_no_of_patients+","+temp_collectedBy+","+temp_latitude+","+temp_longitude
                                    +","+temp_image1+","+temp_image2+","+temp_image3);
                        }
                        }
                        if(data1.equals("")){
                            display_quarantine_camp_data.setText("No Data Available");

                        }else{
                            display_quarantine_camp_data.setText(data1);
                        }}
                });


    }

    public void export(View view) {
        try{
            //saving the file into device
            String fname="QuarantineCampData"+System.currentTimeMillis()+"";
            FileOutputStream out = openFileOutput(fname+".csv", Context.MODE_PRIVATE);
            out.write((data.toString()).getBytes());
            out.close();

            //exporting
            Context context = getApplicationContext();
            File filelocation = new File(getFilesDir(), fname+".csv");
            Uri path = FileProvider.getUriForFile(context, "com.example.asha_app.fileprovider", filelocation);
            Intent fileIntent = new Intent(Intent.ACTION_SEND);
            fileIntent.setType("text/csv");
            fileIntent.putExtra(Intent.EXTRA_SUBJECT, "Data");
            fileIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            fileIntent.putExtra(Intent.EXTRA_STREAM, path);
            startActivity(Intent.createChooser(fileIntent, "Send mail"));
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }
}