package com.example.asha_app;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class ViewListOfWorkers extends AppCompatActivity {
Spinner spinner;
EditText to_date,from_date;
    public DatePickerDialog.OnDateSetListener mDateSetListener_to;
    public DatePickerDialog.OnDateSetListener mDateSetListener_from;
    List<String> names = new ArrayList<>();
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference workers_collection=db.collection("Workers");
    private DocumentReference workers_documents;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_list_of_workers);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        spinner=(Spinner)findViewById(R.id.spinner);
        spinner.setVisibility(View.GONE);
        names.add("All");
        to_date=(EditText)findViewById(R.id.edit_text_to);
        from_date=(EditText)findViewById(R.id.edit_text_from);
        from_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(
                        ViewListOfWorkers.this,
                        android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        mDateSetListener_from,
                        year,month,day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();

            }
        });
        mDateSetListener_from = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                month = month + 1;
                String date = String.format("%02d-%02d-%04d",day,month,year);
                try {
                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
                    Date date1 = new Date();
                    String dateTime1 = dateFormat.format(date1);
                    if((dateFormat.parse(date)).compareTo(dateFormat.parse(dateTime1))>0){
                        Toast.makeText(ViewListOfWorkers.this, "Improper date", Toast.LENGTH_SHORT).show();
                        from_date.setText("");
                    }
                    else{
                        from_date.setText(date);

                    }

                } catch (Exception e) {
                    //Toast.makeText(ViewListOfWorkers.this, "Error_from", Toast.LENGTH_LONG).show();
                }

            }
        };
        to_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog = new DatePickerDialog(
                        ViewListOfWorkers.this,
                        android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        mDateSetListener_to,
                        year,month,day);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.show();
            }
        });
        mDateSetListener_to = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                month = month + 1;
                String date = String.format("%02d-%02d-%04d",day,month,year);
                try {
                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
                    Date date1 = new Date();
                    String dateTime1 = dateFormat.format(date1);
                    if((dateFormat.parse(date)).compareTo(dateFormat.parse(dateTime1))>0){
                        Toast.makeText(ViewListOfWorkers.this, "Improper date", Toast.LENGTH_SHORT).show();
                        to_date.setText("");
                    }
                    else{
                       to_date.setText(date);

                    }

                } catch (Exception e) {
                    //Toast.makeText(ViewListOfWorkers.this, "Error_to", Toast.LENGTH_LONG).show();
                }

            }
        };

        workers_collection.get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                        for (QueryDocumentSnapshot documentSnapshot : queryDocumentSnapshots)
                        {
                            String name=documentSnapshot.getString("name");
                            names.add(name);
                        }
                        initialise_names(names);

                    }
                });
    }

    public void nextClicked(View view) {
        //Toast.makeText(this, ""+spinner.getSelectedItem().toString(), Toast.LENGTH_SHORT).show();

        String temp_from_date=from_date.getText().toString();
        String temp_to_date=to_date.getText().toString();
        try {
            if((dateFormat.parse(temp_from_date)).compareTo(dateFormat.parse(temp_to_date))>0) {
                Toast.makeText(this, "Start date can't be greater the end date", Toast.LENGTH_LONG).show();
                return;
            }

        } catch (Exception e) {

        }
        Intent intent=new Intent(getApplicationContext(),DisplayPatientsRegisteredByAshaWorker.class);
        intent.putExtra("worker_name",spinner.getSelectedItem().toString());
        intent.putExtra("to_date",temp_to_date);
        intent.putExtra("from_date",temp_from_date);
        startActivity(intent);
    }
    public  void initialise_names(List<String> names){
        spinner.setVisibility(View.VISIBLE);
        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, names);
        spinner.setAdapter(adapter);
    }
}
