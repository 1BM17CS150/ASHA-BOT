package com.example.asha_app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class ConfirmPatientsBeforeCollectingDetails extends AppCompatActivity {
TextView name,mobile_no;
EditText adhar;
String temp_age;
Button b_continue,load;
String str_worker_name;
    String str_adhar;
    String temp_name;
    String temp_mobile_no;
    private FirebaseFirestore db=FirebaseFirestore.getInstance();
    private CollectionReference admin_collection=db.collection("PublicData");
    private DocumentReference admin_document;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_patients_before_collecting_details);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        Intent i =getIntent();
        str_worker_name=i.getStringExtra("worker_name");
        name=(TextView) findViewById(R.id.name);
        mobile_no=(TextView) findViewById(R.id.mobile_no);
        adhar=(EditText)findViewById(R.id.adhar_no);
        b_continue=(Button)findViewById(R.id.b_continue);
        load=(Button)findViewById(R.id.load);
        //b_continue.setEnabled(false);
        b_continue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(name.getText().toString().equals("")){
                    Toast.makeText(ConfirmPatientsBeforeCollectingDetails.this, "Please Load the Data", Toast.LENGTH_SHORT).show();
                }else{
                Intent intent = new Intent(getApplicationContext(),Collect_details_of_public.class);
                intent.putExtra("worker_name",str_worker_name);
                intent.putExtra("patient_name",temp_name);
                intent.putExtra("adhar_no",str_adhar);
                intent.putExtra("age",temp_age);
                intent.putExtra("mobile_no",temp_mobile_no);
                startActivity(intent);}
            }
        });

    }

    public void onLoad(View view) {
        int flag=0;
        str_adhar=adhar.getText().toString();
        if (str_adhar.isEmpty()){
            Toast.makeText(getApplicationContext(), "Adhar number empty", Toast.LENGTH_SHORT).show();
            flag=1;
        }
        if(flag==0){
            admin_document=admin_collection.document(str_adhar);
            admin_document.get()
                    .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists()) {
                                temp_name = documentSnapshot.getString("name");
                                temp_mobile_no = documentSnapshot.getString("mobile_no");
                                temp_age=documentSnapshot.getString("age");
                                name.setText(temp_name);
                                mobile_no.setText(temp_mobile_no);
                                b_continue.setEnabled(true);

                            }
                            else {
                                Toast.makeText(getApplicationContext(), "Patients Does Not Exists, Please register the Patients", Toast.LENGTH_LONG).show();
                            }
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(getApplicationContext(), "Error!", Toast.LENGTH_SHORT).show();
                            Log.d("Error", e.toString());
                        }
                    });}
    }
}
