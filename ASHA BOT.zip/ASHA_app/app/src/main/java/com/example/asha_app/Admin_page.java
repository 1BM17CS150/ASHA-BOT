package com.example.asha_app;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

public class Admin_page extends AppCompatActivity {
    String admin_name="";
TextView adminName;
    AlertDialog.Builder builder;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_page);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        Intent i=getIntent();
        admin_name=i.getStringExtra("admin_name");
        adminName=(TextView)findViewById(R.id.admin_name);
        adminName.setText(admin_name);
        builder = new AlertDialog.Builder(this);

    }

    @Override
    public void onBackPressed() {
        builder.setMessage("Going Back will Log Out Session!")
                .setCancelable(false)
                .setPositiveButton("Logout", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        finish();
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();

                    }
                });
        AlertDialog alert = builder.create();
        alert.setTitle("Please Confirm");
        alert.show();
    }

    public void logout(View view) {
        Intent intent = new Intent(getApplicationContext(), Main_login.class);
        startActivity(intent);
        finish();
    }

    public void RegisterAshaWorker(View view) {
        Intent intent = new Intent(getApplicationContext(), Register_ASHA_worker_by_admin.class);
        startActivity(intent);
    }

    public void ViewPatientsDetails(View view) {
        Intent intent = new Intent(getApplicationContext(), ViewListOfWorkers.class);
        startActivity(intent);
    }

    public void ContainmentDetails(View view) {
        Intent intent = new Intent(getApplicationContext(), ViewContainmentData.class);
        startActivity(intent);
    }

    public void Quarantine_Camp_Data(View view) {
        Intent intent = new Intent(getApplicationContext(), ViewQuarantineData.class);
        startActivity(intent);
    }

    public void WorkerDetails(View view) {
        Intent intent = new Intent(getApplicationContext(), AshaWorkerDetails.class);
        startActivity(intent);
    }

    public void HospitalDetails(View view) {
        Intent intent = new Intent(getApplicationContext(), ViewHospitalData.class);
        startActivity(intent);
    }

    public void PublicDetails(View view) {
        Intent intent = new Intent(getApplicationContext(), ViewRegisteredPublicData.class);
        startActivity(intent);
    }

    public void RemoveWorkers(View view) {
        Intent intent = new Intent(getApplicationContext(), Remove_Worker.class);
        startActivity(intent);
    }

    public void Update_password(View view) {
        Intent intent = new Intent(getApplicationContext(), Admin_password_change.class);
        intent.putExtra("admin_name",admin_name);
        startActivity(intent);
    }
}
