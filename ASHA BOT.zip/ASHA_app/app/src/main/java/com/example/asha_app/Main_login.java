package com.example.asha_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

public class Main_login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_login);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    public void WorkerLogin(View view) {
        Intent i =new Intent(getApplicationContext(),Asha_worker_login.class);
        startActivity(i);

    }

    public void AdminLogin(View view) {
        Intent i =new Intent(getApplicationContext(),Admin_login.class);
        startActivity(i);

    }
}
