package com.example.asha_app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class Admin_login extends AppCompatActivity {
    TextInputEditText username,password;
    Button signin;
    private FirebaseFirestore db=FirebaseFirestore.getInstance();
    private CollectionReference admin_collection=db.collection("Admin");
    private DocumentReference admin_document;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        username=(TextInputEditText)findViewById(R.id.username);
        password=(TextInputEditText)findViewById(R.id.password);
        signin=(Button)findViewById(R.id.sign_in);
        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String u=username.getText().toString();
                final String p=password.getText().toString();
                int flag=0;
                if (u.isEmpty()){
                    Toast.makeText(getApplicationContext(), "Fields are empty", Toast.LENGTH_SHORT).show();
                    flag=1;
                }
                if(flag==0){
                    admin_document=admin_collection.document(u);
                    admin_document.get()
                            .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                                @Override
                                public void onSuccess(DocumentSnapshot documentSnapshot) {
                                    if (documentSnapshot.exists()) {
                                        String temp_pass = documentSnapshot.getString("password");
                                        if(temp_pass.equals(p)){
                                            username.setText("");
                                            password.setText("");
                                            //Toast.makeText(getApplicationContext(), "Password Matches", Toast.LENGTH_SHORT).show();
                                            Intent intent = new Intent(getApplicationContext(),Admin_page.class);
                                            intent.putExtra("admin_name",u);
                                            startActivity(intent);
                                            finish();

                                        }
                                        else
                                        {
                                            Toast.makeText(getApplicationContext(), "Wrong Password ", Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                    else {
                                        Toast.makeText(getApplicationContext(), "User Does Not Exists", Toast.LENGTH_LONG).show();
                                    }
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(getApplicationContext(), "Error!", Toast.LENGTH_SHORT).show();
                                    Log.d("Error", e.toString());
                                }
                            });}
            }
        });
    }
}
